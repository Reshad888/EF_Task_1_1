﻿namespace EF_Task_1_1.Entities;

internal class Author : BaseEntity
{
    // Properties
    public string FirstName { get; set; }
    public string LastName { get; set; }

    // Navigation Properties
    public ICollection<Book> Books { get; set; }
}