﻿namespace EF_Task_1_1.Entities;

internal class Operation
{
    // Properties
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}