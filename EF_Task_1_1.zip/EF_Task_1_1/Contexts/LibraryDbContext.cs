﻿using EF_Task_1_1.Entities;
using Microsoft.EntityFrameworkCore;
namespace EF_Task_1_1.Contexts;

public class LibraryDbContext : DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        //string connectionString = "Data Source = DESKTOP-RH41O1K\\SQLEXPRESS;" +
        //    "Initial Catalog = LibraryDb" +
        //    "Integrated Security = True;" +
        //    "Connect Timeout = 30;" +
        //    "Encrypt = True;" +
        //    "Trust Server Certificate = True;" +
        //    "Application Intent = ReadWrite;" +
        //    "Multi Subnet Failover = False";

        string conString = "Data Source = DESKTOP-RH41O1K\\SQLEXPRESS;" +
            "Initial Catalog = LibraryDb;" +
            "Integrated Security = True;";
        optionsBuilder.UseSqlServer("hello");
        base.OnConfiguring(optionsBuilder);
    }

    public DbSet<Student> Students { get; set; }
    public DbSet<Book> Books { get; set; }
    public DbSet<Author> Authors { get; set; }
    public DbSet<BookType> BookTypes { get; set; }
    public DbSet<Operation> Operations { get; set; }
}