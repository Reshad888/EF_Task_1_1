﻿namespace EF_Task_1_1.Enums;

internal enum DataStatus
{
    Inserted,
    Updated,
    Deleted
}