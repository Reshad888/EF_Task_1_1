﻿namespace EF_Task_1_1.Enums;

internal enum Gender
{
    Male = 0,
    Female = 1
}